	$(document).ready(function() {
 	$('ul.sf-menu').superfish({
      delay:       800,                            
      animation:   {height:'show'}, 
      speed:       'faster',                          
      autoArrows:  false,                   
      dropShadows: false                         
   });
 });